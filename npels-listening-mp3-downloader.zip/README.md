# NPELS 课程测试 Chrome 辅助扩展

## 功能

  - 显示听力录音下载按钮
  - 使用 HTML5 audio 元素实现听力录音播放，因此在 Flash 被默认禁用的 Chrome 中也可以完成所有测试

![](img/feature.png)
![](img/extension.png)
